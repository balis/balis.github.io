object tutorial4 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(149); 
  //////////////////
  // 1. Implicits //
  //////////////////

  // a) conversion
  implicit def double2Int(d: Double) = d.toInt;System.out.println("""double2Int: (d: Double)Int""");$skip(20); 
  val x: Int = 44.0;System.out.println("""x  : Int = """ + $show(x ));$skip(43); 

  implicit def defaultVal: Double = 42.0;System.out.println("""defaultVal: => Double""");$skip(113); 
  //implicit def otherVal: Double = 40.0

  // b) implicit parameter
  def foo(implicit x: Double) = println(x);System.out.println("""foo: (implicit x: Double)Unit""");$skip(6); 
  foo;$skip(182); 

  //////////////////////////
  // 2. Partial functions //
  //////////////////////////

  val root: PartialFunction[Double, Double] = {
    case d if (d >= 0) => math.sqrt(d)
  };System.out.println("""root  : PartialFunction[Double,Double] = """ + $show(root ));$skip(23); val res$0 = 

  root isDefinedAt -1;System.out.println("""res0: Boolean = """ + $show(res$0));$skip(145); val res$1 = 

  // collect applies a partial function to all list elements for which it is defined, and creates a new list
  List(-2.0, 0, 2, 4) collect root;System.out.println("""res1: List[Double] = """ + $show(res$1))}

  // Documentation: http://www.scala-lang.org/api/current/index.html#scala.PartialFunction
  
}
