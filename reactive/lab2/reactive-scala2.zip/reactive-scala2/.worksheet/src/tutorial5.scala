object tutorial5 {

  ///////////////////////////////////////
  // Case classes and Pattern matching //
  ///////////////////////////////////////

  trait Expr
  case class Number(n: Int) extends Expr
  case class Sum(e1: Expr, e2: Expr) extends Expr;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(592); 

  // Case classes are special classes for which:
  // 1. the compiler automatically generates a companion object with method "apply"
  //      object Number {
  //          def apply(n: Int) = new Number(n)
  //      }
  // 2.

  def eval(e: Expr): Int = e match {
    case Number(n) => n
    case Sum(e1, e2) => eval(e1) + eval(e2)
  };System.out.println("""eval: (e: tutorial5.Expr)Int""")}
}
